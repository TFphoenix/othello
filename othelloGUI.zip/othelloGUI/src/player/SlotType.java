package player;

public enum SlotType {
    Empty,
    White,
    Black
}